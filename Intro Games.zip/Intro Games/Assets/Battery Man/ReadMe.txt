﻿Battery Man
@author Harley Maurone

Version 1.0

Battery Man is an arcade style platform jumper with a special twist. The object is to get the highest score.

This game is still a work in progress, however the plan is to fix animations, add dynamic lighting effects, a "health bar", add "battery packs" to refill the health bar, have the game get dynamically faster and harder overtime,
and add another control to increase the speed of the player from waslking to sprinting.

Simple Controls 
	A key is to move player left
	D key is to move player right
	Spacebar is to make player jump upwards.

Hope you have fun playing Battery Man!